define('applicationController',{
    appInit: function(params) {
        skinsInit();
        voltmx.mvc.registry.add("com.hcl.mario.Divider", {
            "viewName": "Divider",
            "controllerName": "DividerController"
        });
        voltmx.application.registerMaster({
            "namespace": "com.hcl.mario",
            "classname": "Divider",
            "name": "com.hcl.mario.Divider"
        });
        voltmx.mvc.registry.add("com.hcl.mario.Rectangle", {
            "viewName": "Rectangle",
            "controllerName": "RectangleController"
        });
        voltmx.application.registerMaster({
            "namespace": "com.hcl.mario",
            "classname": "Rectangle",
            "name": "com.hcl.mario.Rectangle"
        });
        voltmx.mvc.registry.add("com.hcl.mario.Square", {
            "viewName": "Square",
            "controllerName": "SquareController"
        });
        voltmx.application.registerMaster({
            "namespace": "com.hcl.mario",
            "classname": "Square",
            "name": "com.hcl.mario.Square"
        });
        voltmx.mvc.registry.add("com.hcl.mario.SquareListArea", {
            "viewName": "SquareListArea",
            "controllerName": "SquareListAreaController"
        });
        voltmx.application.registerMaster({
            "namespace": "com.hcl.mario",
            "classname": "SquareListArea",
            "name": "com.hcl.mario.SquareListArea"
        });
        voltmx.mvc.registry.add("com.hcl.mario.SquareSplitArea", {
            "viewName": "SquareSplitArea",
            "controllerName": "SquareSplitAreaController"
        });
        voltmx.application.registerMaster({
            "namespace": "com.hcl.mario",
            "classname": "SquareSplitArea",
            "name": "com.hcl.mario.SquareSplitArea"
        });
        voltmx.mvc.registry.add("flxSampleRowTemplate", {
            "viewName": "flxSampleRowTemplate",
            "controllerName": "flxSampleRowTemplateController"
        });
        voltmx.mvc.registry.add("flxSectionHeaderTemplate", {
            "viewName": "flxSectionHeaderTemplate",
            "controllerName": "flxSectionHeaderTemplateController"
        });
        voltmx.mvc.registry.add("frmDragAndDropMove", {
            "viewName": "frmDragAndDropMove",
            "controllerName": "frmDragAndDropMoveController"
        });
        voltmx.mvc.registry.add("frmDragAndDropToolbox", {
            "viewName": "frmDragAndDropToolbox",
            "controllerName": "frmDragAndDropToolboxController"
        });
        voltmx.mvc.registry.add("frmHome", {
            "viewName": "frmHome",
            "controllerName": "frmHomeController"
        });
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new voltmx.mvc.Navigation("frmHome").navigate();
    }
});

define("com/hcl/mario/Divider/userDividerController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        showTarget(visible) {
            this.view.flxTarget.setVisibility(visible);
            this.view.flxTarget.height = visible ? '70dp' : '0dp';
            this.view.height = visible ? '80dp' : '10dp';
            this.view.flxTarget.forceLayout();
            this.view.forceLayout();
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/mario/Divider/DividerControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/mario/Divider/DividerController", ["com/hcl/mario/Divider/userDividerController", "com/hcl/mario/Divider/DividerControllerActions"], function() {
    var controller = require("com/hcl/mario/Divider/userDividerController");
    var actions = require("com/hcl/mario/Divider/DividerControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/mario/Divider/Divider',[],function() {
    return function(controller) {
        var Divider = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "10dp",
            "id": "Divider",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "skinLightBlue",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "DragAndDrop"
        }, controller.args[0], "Divider"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "Divider"), extendConfig({}, controller.args[2], "Divider"));
        Divider.setDefaultUnit(voltmx.flex.DP);
        var flxTop = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "5dp",
            "id": "flxTop",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "DragAndDrop"
        }, controller.args[0], "flxTop"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxTop"), extendConfig({}, controller.args[2], "flxTop"));
        flxTop.setDefaultUnit(voltmx.flex.DP);
        flxTop.add();
        var flxTarget = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "0dp",
            "id": "flxTarget",
            "isVisible": false,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "skinGreyBorderBlack",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "DragAndDrop"
        }, controller.args[0], "flxTarget"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxTarget"), extendConfig({}, controller.args[2], "flxTarget"));
        flxTarget.setDefaultUnit(voltmx.flex.DP);
        flxTarget.add();
        var flxBottom = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "5dp",
            "id": "flxBottom",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "DragAndDrop"
        }, controller.args[0], "flxBottom"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxBottom"), extendConfig({}, controller.args[2], "flxBottom"));
        flxBottom.setDefaultUnit(voltmx.flex.DP);
        flxBottom.add();
        Divider.add(flxTop, flxTarget, flxBottom);
        return Divider;
    }
})
;
define('com/hcl/mario/Divider/DividerConfig',[],function() {
    return {
        "properties": [],
        "apis": ["showTarget"],
        "events": []
    }
});

define("com/hcl/mario/Rectangle/userRectangleController", [],function() {
    return {
        constructor(baseConfig, layoutConfig, pspConfig) {
            this.view.flxDelete.onTouchStart = () => {
                if (!DragAndDrop.suspendEvents) {
                    //           voltmx.sdk.logsdk.info(`onTouchStart: ${this.view.id} ${this.view.flxRectangle.skin}`);
                    DragAndDrop.suspendEvents = true;
                    globals.objectToDelete || (globals.objectToDelete = this.view.id);
                }
            };
            this.view.flxDelete.onTouchEnd = () => {
                if (globals.objectToDelete === this.view.id) {
                    //           voltmx.sdk.logsdk.info(`onTouchEnd: ${this.view.id} ${this.view.flxRectangle.skin}`);
                    this.onDelete();
                    setTimeout(() => {
                        globals.objectToDelete = null;
                        DragAndDrop.suspendEvents = false;
                    }, 300);
                }
            };
        },
        initGettersSetters() {},
        onDelete() {},
        getDragClone(id) {
            const rectangle = new com.hcl.mario.Rectangle({
                id
            }, {}, {});
            rectangle.skinRectangle = this.view.flxRectangle.skin;
            return rectangle;
        }
    };
});
define("com/hcl/mario/Rectangle/RectangleControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/mario/Rectangle/RectangleController", ["com/hcl/mario/Rectangle/userRectangleController", "com/hcl/mario/Rectangle/RectangleControllerActions"], function() {
    var controller = require("com/hcl/mario/Rectangle/userRectangleController");
    var actions = require("com/hcl/mario/Rectangle/RectangleControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "skinRectangle", function(val) {
            this.view.flxRectangle.skin = val;
        });
        defineGetter(this, "skinRectangle", function() {
            return this.view.flxRectangle.skin;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/mario/Rectangle/Rectangle',[],function() {
    return function(controller) {
        var Rectangle = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "70dp",
            "id": "Rectangle",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "DragAndDrop"
        }, controller.args[0], "Rectangle"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "Rectangle"), extendConfig({}, controller.args[2], "Rectangle"));
        Rectangle.setDefaultUnit(voltmx.flex.DP);
        var flxRectangle = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxRectangle",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "skinDarkGrey",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "DragAndDrop"
        }, controller.args[0], "flxRectangle"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxRectangle"), extendConfig({}, controller.args[2], "flxRectangle"));
        flxRectangle.setDefaultUnit(voltmx.flex.DP);
        var flxDelete = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "40dp",
            "id": "flxDelete",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "right": 0,
            "skin": "slFbox",
            "top": "0dp",
            "width": "40dp",
            "appName": "DragAndDrop"
        }, controller.args[0], "flxDelete"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxDelete"), extendConfig({}, controller.args[2], "flxDelete"));
        flxDelete.setDefaultUnit(voltmx.flex.DP);
        var lblDelete = new voltmx.ui.Label(extendConfig({
            "height": "40dp",
            "id": "lblDelete",
            "isVisible": true,
            "right": 0,
            "skin": "skinIcon",
            "text": "",
            "textStyle": {},
            "top": "0dp",
            "width": "40dp",
            "zIndex": 1
        }, controller.args[0], "lblDelete"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDelete"), extendConfig({}, controller.args[2], "lblDelete"));
        flxDelete.add(lblDelete);
        flxRectangle.add(flxDelete);
        Rectangle.add(flxRectangle);
        Rectangle.compInstData = {}
        return Rectangle;
    }
})
;
define('com/hcl/mario/Rectangle/RectangleConfig',[],function() {
    return {
        "properties": [{
            "name": "skinRectangle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["getDragClone"],
        "events": ["onDelete"]
    }
});

define("com/hcl/mario/Square/userSquareController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        getDragClone(id) {
            return new com.hcl.mario.Square({
                id,
                skin: this.view.skin
            }, {}, {});
        }
    };
});
define("com/hcl/mario/Square/SquareControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/mario/Square/SquareController", ["com/hcl/mario/Square/userSquareController", "com/hcl/mario/Square/SquareControllerActions"], function() {
    var controller = require("com/hcl/mario/Square/userSquareController");
    var actions = require("com/hcl/mario/Square/SquareControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/mario/Square/Square',[],function() {
    return function(controller) {
        var Square = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "50dp",
            "id": "Square",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "skinRed",
            "top": "0dp",
            "width": "50dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "DragAndDrop"
        }, controller.args[0], "Square"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "Square"), extendConfig({}, controller.args[2], "Square"));
        Square.setDefaultUnit(voltmx.flex.DP);
        Square.add();
        Square.compInstData = {}
        return Square;
    }
})
;
define('com/hcl/mario/Square/SquareConfig',[],function() {
    return {
        "properties": [],
        "apis": ["getDragClone"],
        "events": []
    }
});

define("com/hcl/mario/SquareListArea/userSquareListAreaController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        getDragClone(id) {
            return new com.hcl.mario.SquareListArea({
                id
            }, {}, {});
        }
    };
});
define("com/hcl/mario/SquareListArea/SquareListAreaControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/mario/SquareListArea/SquareListAreaController", ["com/hcl/mario/SquareListArea/userSquareListAreaController", "com/hcl/mario/SquareListArea/SquareListAreaControllerActions"], function() {
    var controller = require("com/hcl/mario/SquareListArea/userSquareListAreaController");
    var actions = require("com/hcl/mario/SquareListArea/SquareListAreaControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/mario/SquareListArea/SquareListArea',[],function() {
    return function(controller) {
        var SquareListArea = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "50dp",
            "id": "SquareListArea",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "skinDarkGrey",
            "top": "0dp",
            "width": "50dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "DragAndDrop"
        }, controller.args[0], "SquareListArea"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "SquareListArea"), extendConfig({}, controller.args[2], "SquareListArea"));
        SquareListArea.setDefaultUnit(voltmx.flex.DP);
        var flxInner = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": false,
            "height": "30dp",
            "id": "flxInner",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "27dp",
            "isModalContainer": false,
            "skin": "skinGrey",
            "top": "25dp",
            "width": "30dp",
            "zIndex": 1,
            "appName": "DragAndDrop"
        }, controller.args[0], "flxInner"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxInner"), extendConfig({}, controller.args[2], "flxInner"));
        flxInner.setDefaultUnit(voltmx.flex.DP);
        flxInner.add();
        SquareListArea.add(flxInner);
        SquareListArea.compInstData = {}
        return SquareListArea;
    }
})
;
define('com/hcl/mario/SquareListArea/SquareListAreaConfig',[],function() {
    return {
        "properties": [],
        "apis": ["getDragClone"],
        "events": []
    }
});

define("com/hcl/mario/SquareSplitArea/userSquareSplitAreaController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {},
        getDragClone(id) {
            return new com.hcl.mario.SquareSplitArea({
                id
            }, {}, {});
        }
    };
});
define("com/hcl/mario/SquareSplitArea/SquareSplitAreaControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/mario/SquareSplitArea/SquareSplitAreaController", ["com/hcl/mario/SquareSplitArea/userSquareSplitAreaController", "com/hcl/mario/SquareSplitArea/SquareSplitAreaControllerActions"], function() {
    var controller = require("com/hcl/mario/SquareSplitArea/userSquareSplitAreaController");
    var actions = require("com/hcl/mario/SquareSplitArea/SquareSplitAreaControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/mario/SquareSplitArea/SquareSplitArea',[],function() {
    return function(controller) {
        var SquareSplitArea = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "50dp",
            "id": "SquareSplitArea",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "skinDarkGrey",
            "top": "0dp",
            "width": "50dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "DragAndDrop"
        }, controller.args[0], "SquareSplitArea"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "SquareSplitArea"), extendConfig({}, controller.args[2], "SquareSplitArea"));
        SquareSplitArea.setDefaultUnit(voltmx.flex.DP);
        var flxInnerLeft = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": false,
            "height": "30dp",
            "id": "flxInnerLeft",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "10dp",
            "isModalContainer": false,
            "skin": "skinGrey",
            "width": "13dp",
            "zIndex": 1,
            "appName": "DragAndDrop"
        }, controller.args[0], "flxInnerLeft"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxInnerLeft"), extendConfig({}, controller.args[2], "flxInnerLeft"));
        flxInnerLeft.setDefaultUnit(voltmx.flex.DP);
        flxInnerLeft.add();
        var flxInnerRight = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": false,
            "height": "30dp",
            "id": "flxInnerRight",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "4dp",
            "isModalContainer": false,
            "skin": "skinGrey",
            "width": "13dp",
            "zIndex": 1,
            "appName": "DragAndDrop"
        }, controller.args[0], "flxInnerRight"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxInnerRight"), extendConfig({}, controller.args[2], "flxInnerRight"));
        flxInnerRight.setDefaultUnit(voltmx.flex.DP);
        flxInnerRight.add();
        SquareSplitArea.add(flxInnerLeft, flxInnerRight);
        SquareSplitArea.compInstData = {}
        return SquareSplitArea;
    }
})
;
define('com/hcl/mario/SquareSplitArea/SquareSplitAreaConfig',[],function() {
    return {
        "properties": [],
        "apis": ["getDragClone"],
        "events": []
    }
});

define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate",
            "width": "100%",
            "appName": "DragAndDrop"
        }, {
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.setDefaultUnit(voltmx.flex.DP);
        var lblHeading = new voltmx.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblDescription = new voltmx.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTime = new voltmx.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblStrip = new voltmx.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("flxSectionHeaderTemplate", [],function() {
    return function(controller) {
        var flxSectionHeaderTemplate = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSectionHeaderTemplate",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleSectionHeaderTemplate",
            "width": "100%",
            "appName": "DragAndDrop"
        }, {
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.setDefaultUnit(voltmx.flex.DP);
        var lblHeading = new voltmx.ui.Label({
            "centerY": "50%",
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknSectionHeaderLabelSkin",
            "text": "Heading",
            "textStyle": {},
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxSectionHeaderTemplate.add(lblHeading);
        return flxSectionHeaderTemplate;
    }
})
;
define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("flxSectionHeaderTemplateControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSectionHeaderTemplateController", ["userflxSectionHeaderTemplateController", "flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("userflxSectionHeaderTemplateController");
    var controllerActions = ["flxSectionHeaderTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});

define("navigation/NavigationModel", { 
    "Application": {},
    "Forms" : {},
    "UIModules" : {}
});

define("navigation/NavigationController", {
    //Add your navigation controller code here.
});

require(['applicationController','com/hcl/mario/Divider/DividerController','com/hcl/mario/Divider/Divider','com/hcl/mario/Divider/DividerConfig','com/hcl/mario/Rectangle/RectangleController','com/hcl/mario/Rectangle/Rectangle','com/hcl/mario/Rectangle/RectangleConfig','com/hcl/mario/Square/SquareController','com/hcl/mario/Square/Square','com/hcl/mario/Square/SquareConfig','com/hcl/mario/SquareListArea/SquareListAreaController','com/hcl/mario/SquareListArea/SquareListArea','com/hcl/mario/SquareListArea/SquareListAreaConfig','com/hcl/mario/SquareSplitArea/SquareSplitAreaController','com/hcl/mario/SquareSplitArea/SquareSplitArea','com/hcl/mario/SquareSplitArea/SquareSplitAreaConfig','flxSampleRowTemplate','flxSectionHeaderTemplate','flxSampleRowTemplateController','flxSectionHeaderTemplateController','navigation/NavigationModel','navigation/NavigationController'], function(){});

define("sparequirefileslist", function(){});

