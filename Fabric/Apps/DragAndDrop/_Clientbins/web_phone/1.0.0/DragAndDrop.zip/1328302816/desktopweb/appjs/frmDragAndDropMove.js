define("frmDragAndDropMove", function() {
    return function(controller) {
        function addWidgetsfrmDragAndDropMove() {
            this.setDefaultUnit(voltmx.flex.DP);
            var dragArea = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "dragArea",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "DragAndDrop"
            }, {
                "paddingInPixel": false
            }, {});
            dragArea.setDefaultUnit(voltmx.flex.DP);
            var flxSource = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": 200,
                "clipBounds": false,
                "id": "flxSource",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "skinGrey",
                "top": "100dp",
                "width": "300dp",
                "zIndex": 1,
                "appName": "DragAndDrop"
            }, {
                "paddingInPixel": false
            }, {});
            flxSource.setDefaultUnit(voltmx.flex.DP);
            var redCircle = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "redCircle",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "80dp",
                "isModalContainer": false,
                "skin": "skinRedCircle",
                "top": "80dp",
                "width": "100dp",
                "zIndex": 1,
                "appName": "DragAndDrop"
            }, {
                "paddingInPixel": false
            }, {});
            redCircle.setDefaultUnit(voltmx.flex.DP);
            redCircle.add();
            flxSource.add(redCircle);
            var flxTarget = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": 200,
                "clipBounds": false,
                "id": "flxTarget",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "470dp",
                "isModalContainer": false,
                "skin": "skinGrey",
                "top": "100dp",
                "width": "300dp",
                "zIndex": 1,
                "appName": "DragAndDrop"
            }, {
                "paddingInPixel": false
            }, {});
            flxTarget.setDefaultUnit(voltmx.flex.DP);
            flxTarget.add();
            dragArea.add(flxSource, flxTarget);
            var btn1 = new voltmx.ui.Button({
                "bottom": 100,
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btn1",
                "isVisible": true,
                "left": "100dp",
                "onClick": controller.AS_Button_fe99d7b37fd44e689fad2bf6fce0e2c0,
                "skin": "defBtnNormal",
                "text": "Back to Home Page",
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo = new voltmx.ui.Label({
                "id": "lblInfo",
                "isVisible": true,
                "left": "30dp",
                "skin": "lblInfo",
                "text": "Drag and drop the red circle inside the grey areas.",
                "top": "55dp",
                "width": "1000dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(dragArea, btn1, lblInfo);
        };
        return [{
            "addWidgets": addWidgetsfrmDragAndDropMove,
            "enabledForIdleTimeout": false,
            "id": "frmDragAndDropMove",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "DragAndDrop"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});