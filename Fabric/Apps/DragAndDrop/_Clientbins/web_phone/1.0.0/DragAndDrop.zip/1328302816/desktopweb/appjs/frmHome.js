define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(voltmx.flex.DP);
            var lblInfo = new voltmx.ui.Label({
                "id": "lblInfo",
                "isVisible": true,
                "left": "50dp",
                "skin": "lblInfo",
                "text": "This project contains two sample implementations built using the DragAndDrop class.",
                "top": "55dp",
                "width": "1000dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo2 = new voltmx.ui.Label({
                "id": "lblInfo2",
                "isVisible": true,
                "left": "50dp",
                "skin": "lblInfo",
                "text": "In the first sample one can drag an drop an object in the grey areas. It is a simple implementation which demonstrates a basic usage of the class.",
                "top": "30dp",
                "width": "1000dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btn1 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btn1",
                "isVisible": true,
                "left": "50dp",
                "onClick": controller.AS_Button_fb8325e80ac6454e8007f848972b754d,
                "skin": "defBtnNormal",
                "text": "Go to the first sample",
                "top": "20dp",
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo3 = new voltmx.ui.Label({
                "id": "lblInfo3",
                "isVisible": true,
                "left": "50dp",
                "skin": "lblInfo",
                "text": "The second sample is much more complex. There is a palette on the right from which one can drag and drop assets inside the target area. The assets can be reordered and removed.",
                "top": "30dp",
                "width": "1000dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btn2 = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btn2",
                "isVisible": true,
                "left": "50dp",
                "onClick": controller.AS_Button_d32d6d204f3f438890c4f9a466498178,
                "skin": "defBtnNormal",
                "text": "Go to the second sample",
                "top": "20dp",
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(lblInfo, lblInfo2, btn1, lblInfo3, btn2);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "DragAndDrop"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});