define("userfrmHomeController", {
    //Type your controller code here 
});
define("frmHomeControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_fb8325e80ac6454e8007f848972b754d: function AS_Button_fb8325e80ac6454e8007f848972b754d(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "DragAndDrop",
            "friendlyName": "frmDragAndDropMove"
        });
        ntf.navigate();
    },
    AS_Button_d32d6d204f3f438890c4f9a466498178: function AS_Button_d32d6d204f3f438890c4f9a466498178(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "DragAndDrop",
            "friendlyName": "frmDragAndDropToolbox"
        });
        ntf.navigate();
    }
});
define("frmHomeController", ["userfrmHomeController", "frmHomeControllerActions"], function() {
    var controller = require("userfrmHomeController");
    var controllerActions = ["frmHomeControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
