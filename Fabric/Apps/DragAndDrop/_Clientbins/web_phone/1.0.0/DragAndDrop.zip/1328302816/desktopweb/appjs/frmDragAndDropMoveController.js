define("userfrmDragAndDropMoveController", {
    dnd: null,
    onViewCreated() {
        this.view.init = () => {
            this.dnd = new DragAndDrop(this.view);
            this.dnd.makeDragArea(this.view.dragArea, this.dragCallback, this.endCallback);
            this.dnd.makeDraggable(this.view.redCircle, this.view.redCircle.clone(`${new Date().getTime()}`));
            this.dnd.makeDropArea(this.view.flxSource, this.moveCallback, this.dropCallback);
            this.dnd.makeDropArea(this.view.flxTarget, this.moveCallback, this.dropCallback);
            this.dnd.addSourceArea(this.view.flxSource);
            this.dnd.addTargetArea(this.view.flxTarget);
        };
    },
    dragCallback(draggedObject) {},
    moveCallback(draggedObject, dropArea) {
        this.dnd.getSourceObject().isVisible = false;
    },
    dropCallback(draggedObject, dropArea) {
        const {
            x,
            y
        } = dropArea.convertPointFromWidget(draggedObject.frame, this.view.dragArea);
        draggedObject.parent.remove(draggedObject);
        this.dnd.getSourceObject().isVisible = true;
        this.dnd.getSourceObject().removeFromParent();
        dropArea.add(this.dnd.getSourceObject());
        this.dnd.getSourceObject().left = x;
        this.dnd.getSourceObject().top = y;
        dropArea.forceLayout();
    },
    endCallback() {
        this.dnd.getSourceObject().isVisible = true;
    }
});
define("frmDragAndDropMoveControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_fe99d7b37fd44e689fad2bf6fce0e2c0: function AS_Button_fe99d7b37fd44e689fad2bf6fce0e2c0(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "DragAndDrop",
            "friendlyName": "frmHome"
        });
        ntf.navigate();
    }
});
define("frmDragAndDropMoveController", ["userfrmDragAndDropMoveController", "frmDragAndDropMoveControllerActions"], function() {
    var controller = require("userfrmDragAndDropMoveController");
    var controllerActions = ["frmDragAndDropMoveControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
