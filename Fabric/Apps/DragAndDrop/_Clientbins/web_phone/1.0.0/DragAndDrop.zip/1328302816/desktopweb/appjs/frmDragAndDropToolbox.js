define("frmDragAndDropToolbox", function() {
    return function(controller) {
        function addWidgetsfrmDragAndDropToolbox() {
            this.setDefaultUnit(voltmx.flex.DP);
            var dragArea = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "dragArea",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "DragAndDrop"
            }, {
                "paddingInPixel": false
            }, {});
            dragArea.setDefaultUnit(voltmx.flex.DP);
            var targetArea = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": 200,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "targetArea",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "30dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "skinFlsGrey",
                "top": "100dp",
                "verticalScrollIndicator": true,
                "width": "1070dp"
            }, {
                "paddingInPixel": false
            }, {});
            targetArea.setDefaultUnit(voltmx.flex.DP);
            var topDivider = new com.hcl.mario.Divider({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "topDivider",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "skinLightBlue",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "DragAndDrop",
                "viewType": "topDivider",
                "overrides": {
                    "Divider": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            targetArea.add(topDivider);
            var sourceArea = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": 200,
                "clipBounds": false,
                "id": "sourceArea",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "1160dp",
                "isModalContainer": false,
                "skin": "skinGrey",
                "top": "100dp",
                "width": "50dp",
                "appName": "DragAndDrop"
            }, {
                "paddingInPixel": false
            }, {});
            sourceArea.setDefaultUnit(voltmx.flex.DP);
            var red = new com.hcl.mario.Square({
                "height": "50dp",
                "id": "red",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "skinRed",
                "top": "10dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "DragAndDrop",
                "viewType": "red",
                "overrides": {
                    "Square": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var black = new com.hcl.mario.Square({
                "height": "50dp",
                "id": "black",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "skinBlack",
                "top": "10dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "DragAndDrop",
                "viewType": "black",
                "overrides": {
                    "Square": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var yellow = new com.hcl.mario.Square({
                "height": "50dp",
                "id": "yellow",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "skinYellow",
                "top": "10dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "DragAndDrop",
                "viewType": "yellow",
                "overrides": {
                    "Square": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var blue = new com.hcl.mario.Square({
                "height": "50dp",
                "id": "blue",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "skinBlue",
                "top": "10dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "DragAndDrop",
                "viewType": "blue",
                "overrides": {
                    "Square": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var squareListArea = new com.hcl.mario.SquareListArea({
                "height": "50dp",
                "id": "squareListArea",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "skinDarkGrey",
                "top": "10dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "DragAndDrop",
                "viewType": "squareListArea",
                "overrides": {
                    "SquareListArea": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var squareSplitArea = new com.hcl.mario.SquareSplitArea({
                "height": "50dp",
                "id": "squareSplitArea",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "skinDarkGrey",
                "top": "10dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "DragAndDrop",
                "viewType": "squareSplitArea",
                "overrides": {
                    "SquareSplitArea": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            sourceArea.add(red, black, yellow, blue, squareListArea, squareSplitArea);
            dragArea.add(targetArea, sourceArea);
            var btn1 = new voltmx.ui.Button({
                "bottom": 100,
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btn1",
                "isVisible": true,
                "left": "30dp",
                "onClick": controller.AS_Button_f6910537f0ca47a3914b7a9f3ed9e12b,
                "skin": "defBtnNormal",
                "text": "Back to Home Page",
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo = new voltmx.ui.Label({
                "id": "lblInfo",
                "isVisible": true,
                "left": "30dp",
                "skin": "lblInfo",
                "text": "Drag and drop the objects from the palette on the right into the light blue areas.",
                "top": "55dp",
                "width": "1000dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {
                "topDivider": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "red": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "black": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "yellow": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "blue": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "squareListArea": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "squareSplitArea": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(dragArea, btn1, lblInfo);
        };
        return [{
            "addWidgets": addWidgetsfrmDragAndDropToolbox,
            "enabledForIdleTimeout": false,
            "id": "frmDragAndDropToolbox",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "DragAndDrop"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});